﻿using BitmonGeneration1.Source.Battles;
using BitmonGeneration1.Source.BitmonData;
using BitmonGeneration1.Source.Trainers;
using System;
using System.Threading;

namespace BitmonStadiumConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write(" player 1 Enter your name: ");
            string name = Console.ReadLine();
            Console.Clear();

            Console.Write("player 2 Enter your name: ");
            string name1 = Console.ReadLine();
            Console.Clear();




            Console.WriteLine(" {0} Select your  first pokemon: ", name);
            Thread.Sleep(2000);
            Bitmon playersPokemon = SelectBitmon.Choose();
            Console.Clear();


            Console.WriteLine("{0} Select your first pokemon: ", name1);
            Thread.Sleep(2000);
            Bitmon enemypokemon = SelectBitmon.Choose();
            Console.Clear();

            Console.WriteLine("{0}  Select your 2nd pokemon: ", name);
            Thread.Sleep(2000);
            Bitmon players2ndPokemon = SelectBitmon.Choose();
            Console.Clear();

            Console.WriteLine("{0} Select your 2nd pokemon: ", name1);
            Thread.Sleep(2000);
            Bitmon enemy2ndpokemon = SelectBitmon.Choose();
            Console.Clear();

            Console.WriteLine("{0}  Select your 3rd pokemon: ", name);
            Thread.Sleep(2000);
            Bitmon players3rdPokemon = SelectBitmon.Choose();
            Console.Clear();

            Console.WriteLine("{0} Select your 3rd pokemon: ", name1);
            Thread.Sleep(2000);
            Bitmon enemy3rdpokemon = SelectBitmon.Choose();
            Console.Clear();





            Trainer Player = new Trainer(name);

            Player.AddToParty(playersPokemon);
            Player.AddToParty(players2ndPokemon);
            Player.AddToParty(players3rdPokemon);


            Trainer Player2 = new Trainer(name1);

            Player2.AddToParty(enemypokemon);
            Player2.AddToParty(enemy2ndpokemon);
            Player2.AddToParty(enemy3rdpokemon);


            

            Side playerSide = new TrainerSide(Player);
            Side enemySide = new TrainerSide2(Player2);

            ConsoleBattlePlayer.Run(playerSide, enemySide, new ConsoleBattleActor());
            //interactuan los 2 pero solo uno pierde vida

            Console.Write("Press enter to exit");
            Console.ReadLine();
        }
    }
}
