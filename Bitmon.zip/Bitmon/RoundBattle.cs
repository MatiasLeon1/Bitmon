﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BitmonStadiumConsoleApp
{
    public enum RoundBattle
    {
        Match1,
        Match2,
        Match3,
        Match4,
        Match5,
        Match6,
        SemiFinals,
        Finals

    }
}
