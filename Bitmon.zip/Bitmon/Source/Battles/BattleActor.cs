﻿using BitmonGeneration1.Source.Moves;

namespace BitmonGeneration1.Source.Battles
{
    public interface BattleActor
    {
        Selection MakeBeginningOfTurnSelection(Battle battle, Side actorSide);
        Selection MakeForcedSwitchSelection(Battle battle, Side actorSide);

        Selection MakeBeginningOfTurnSelection1(Battle battle, Side enemySide);
        Selection MakeForcedSwitchSelection1(Battle battle, Side enemySide);

        Move PickMoveToMimic(Side opponentSide);
    }
}
