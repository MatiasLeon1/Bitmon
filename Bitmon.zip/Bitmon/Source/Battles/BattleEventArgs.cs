﻿using BitmonGeneration1.Source.BitmonData;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BitmonGeneration1.Source.Battles
{
    public class BattleEventArgs : EventArgs 
    {
        public Battle thisBattle;
    }
}
