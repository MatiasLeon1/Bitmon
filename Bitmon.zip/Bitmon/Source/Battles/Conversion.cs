﻿namespace BitmonGeneration1.Source.Battles
{
    public sealed class Conversion
    {
        public bool IsActive { get; private set; }
        public Type Type1 { get; private set; }
        public Type Type2 { get; private set; }
        

        public void Activate(
            BattleBitmon BitmonToConvertInto)
        {
            IsActive = true;
            Type1 = BitmonToConvertInto.Type1;
            Type2 = BitmonToConvertInto.Type2;
        }

        public void Deactivate()
        {
            IsActive = false;
        }
    }
}
