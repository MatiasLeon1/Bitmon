﻿using BitmonGeneration1.Source.Moves;
using BitmonGeneration1.Source.BitmonData;

namespace BitmonGeneration1.Source.Battles
{
    public abstract class Selection
    {

        public abstract int Priority { get; }
        public abstract void Execute();



        public static Selection MakeFight(
            BattleBitmon user,
            BattleBitmon opponent,
            Move move)
        {
            return new Fight(user, opponent, move);
        }

        public static Selection MakeContinueMultiTurnMove(
            BattleBitmon user,
            BattleBitmon opponent)
        {
            return new ContinueMultiTurnMove(user, opponent);
        }

        public static Selection MakeEmptyFight()
        {
            return new EmptyFight();
        }

        public static Selection MakeSwitchOut(
            BattleBitmon myBattleBitmon,
            BattleBitmon opponentBattleBitmon,
            Bitmon BitmonToSwitchIn)
        {
            return new SwitchOut(
                myBattleBitmon,
                opponentBattleBitmon,
                BitmonToSwitchIn);
        }





        private sealed class Fight : Selection
        {
            private BattleBitmon user;
            private BattleBitmon opponent;
            private Move moveUsed;

            public Fight(
                BattleBitmon user,
                BattleBitmon opponent,
                Move moveUsed)
            {
                this.user = user;
                this.opponent = opponent;
                this.moveUsed = moveUsed;
            }

            public sealed override void Execute()
            {
                if (!user.PartiallyTrapped)
                    user.AttemptMoveExecution(moveUsed, opponent);
            }

            public sealed override int Priority => moveUsed.Priority;
        }




        private sealed class ContinueMultiTurnMove : Selection
        {
            private BattleBitmon user;
            private BattleBitmon defender;

            public ContinueMultiTurnMove(
                BattleBitmon user,
                BattleBitmon defender)
            {
                this.user = user;
                this.defender = defender;
            }
            public sealed override void Execute()
            {
                user.AttemptMoveExecution(
                    user.GetMultiTurnMove(),
                    defender);
            }

            public sealed override int Priority => 0;
        }




        private sealed class EmptyFight : Selection
        {
            public sealed override void Execute() { /* do nothing */ }
            public sealed override int Priority => 0;
        }




        private sealed class SwitchOut : Selection
        {
            BattleBitmon myBattleBitmon;
            BattleBitmon opponentBattleBitmon;
            Bitmon BitmonToSwitchIn;

            public sealed override void Execute()
            {
                myBattleBitmon.SwitchOut(BitmonToSwitchIn);
                opponentBattleBitmon.MirrorMove = null;
            }

            public sealed override int Priority => 2;

            public SwitchOut(
                BattleBitmon myBattleBitmon,
                BattleBitmon opponentBattleBitmon,
                Bitmon BitmonToSwitchIn)
            {
                this.myBattleBitmon = myBattleBitmon;
                this.opponentBattleBitmon = opponentBattleBitmon;
                this.BitmonToSwitchIn = BitmonToSwitchIn;
            }
        }




    }
}
