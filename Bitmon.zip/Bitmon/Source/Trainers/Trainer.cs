﻿using BitmonGeneration1.Source.BitmonData;
using System.Collections.Generic;
using System.Linq;

namespace BitmonGeneration1.Source.Trainers
{
    public class Trainer
    {
        public string Name { get; private set; }
        private List<Bitmon> party;

        public List<Bitmon> Party() => party.ToList();



        public void AddToParty(Bitmon bitmon)
        {
            if (party.Count < 6) party.Add(bitmon);
        }
        


        public Trainer(string name)
        {
            Name = name;
            party = new List<Bitmon>(6);
        }

        public Trainer(string name, List<Bitmon> party)
        {
            Name = name;
            this.party = party;
        }

    }
}
